<button class="btn rey-mainNavigation-mobileBtn rey-headerIcon">
	<span></span>
	<span></span>
	<span></span>
</button>
<!-- .rey-mainNavigation-mobileBtn -->
<div class="rey-mobileBtn-helper"></div>
