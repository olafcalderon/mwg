<header class="rey-pageHeader">
	<?php
		the_archive_title( '<h1 class="rey-pageTitle">', '</h1>' );
		the_archive_description( '<div class="rey-pageTitle-desc">', '</div>' );
	?>
</header><!-- .page-header -->
